# Introduction to factorial

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
