;;ANDREW WIMER PROJECT 3 CSC 226 FACTORIAL PROGRAM
;;APRIL 2020

(ns factorial.core
  (:gen-class))
;;above is the namespace of this program

;;factorial function.
;;returns 1 if the factorial desired is factorial of 1.
;;if not, the argument is multiplied by each subsequent decremented
;;integer recursively until the argument decrements to 1.
(defn factorial [n]
  (if (= n 1)
    1
    (* n (factorial (- n 1)))))

;;parse function
;;parses an integer from a string and returns the argument as an
;;integer.
;;this is done by calling the re-find function,
;;which uses java.util.regex.Matcher.find()
;;This returns the first regex match to our defined pattern,
;; which is the first set of integers found in a string input
(defn parse [z]
  (Integer. (re-find #"\d+" z )))

(defn -main
  "I don't do a whole lot ... yet."
  [& args]

  (println "Enter an integer, 1 or greater. ")
  (println "Integer must be wrapped in double-quotes. ")

  (def x (read-line))
  ;;x variable value will be user input.
  (println (factorial (parse x)))
  ;;factorial function is an argument of println function.
  ;;in turn, parse function with argument x is argument of
  ;;factorial function.
  )

